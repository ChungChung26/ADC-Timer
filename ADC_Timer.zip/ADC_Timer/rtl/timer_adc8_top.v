// ============================================================================
// File: timer_adc8_top.v
// Dynamic: Peripheral top-level wiring apb_regs8, timer8, sar_adc_ctrl, sync_fifo
// ============================================================================
module timer_adc8_top (
    input  wire       clk,
    input  wire       rst_n,

    // Giao tiếp Bus APB (từ Wrapper)
    input  wire       psel,
    input  wire       penable,
    input  wire       pwrite,
    input  wire [3:0] paddr,
    input  wire [7:0] pwdata,
    output wire [7:0] prdata,
    output wire       irq,
    output wire       pwm_out,

    // Giao tiếp với Analog Front-End (AFE)
    output wire       adc_sample,
    output wire [1:0] adc_ch,
    output wire [7:0] adc_dac,
    input  wire       adc_cmp
);

    // ------------------------------------------------------------------------
    // Tín hiệu nối nội bộ
    // ------------------------------------------------------------------------
    // Tín hiệu Timer
    wire [7:0] tmr_ctrl;
    wire [7:0] tmr_presc;
    wire [7:0] tmr_load;
    wire [7:0] tmr_cmp;
    wire [7:0] tmr_cnt;
    wire       tmr_ovf_pulse;
    wire       tmr_cmp_pulse;

    // Tín hiệu ADC
    wire [7:0] adc_ctrl;
    wire [7:0] adc_smp;
    wire [7:0] adc_div;
    wire [7:0] adc_thr_lo;
    wire [7:0] adc_thr_hi;
    wire       adc_busy;
    wire       adc_eoc;
    wire [7:0] adc_result;

    // Tín hiệu FIFO
    wire       fifo_pop;
    wire       fifo_full;
    wire       fifo_empty;
    wire       fifo_ovr;
    wire [3:0] fifo_level;
    wire [9:0] fifo_rdata; // {ch[1:0], data[7:0]}

    // Trigger & IRQ Event Signals
    reg        adc_trig;
    wire       trig_miss;
    wire       adc_wd;

    // ------------------------------------------------------------------------
    // 1. Logic Chọn Nguồn Trigger (Trigger Selection MUX)
    // ------------------------------------------------------------------------
    wire [1:0] trig_sel = adc_ctrl[3:2];

    always @(*) begin
        case (trig_sel)
            2'b00:   adc_trig = adc_ctrl[11];     // Software START bit
            2'b01:   adc_trig = tmr_ovf_pulse;   // Timer Overflow
            2'b10:   adc_trig = tmr_cmp_pulse;   // Timer Compare
            2'b11:   adc_trig = adc_eoc;         // Continuous Mode
            default: adc_trig = 1'b0;
        endcase
    end

    // Phát hiện bỏ lỡ xung kích hoạt khi ADC đang bận
    assign trig_miss = adc_trig && adc_busy;

    // ------------------------------------------------------------------------
    // 2. Logic So sánh Ngưỡng Điện áp (Window Comparator)
    // ------------------------------------------------------------------------
    assign adc_wd = adc_eoc && ((adc_result < adc_thr_lo) || (adc_result > adc_thr_hi));

    // ------------------------------------------------------------------------
    // 3. Khởi tạo Khối Thanh ghi & Ngắt (apb_regs8)
    // ------------------------------------------------------------------------
    apb_regs8 u_regs (
        .clk            (clk),
        .rst_n          (rst_n),
        .psel           (psel),
        .penable        (penable),
        .pwrite         (pwrite),
        .paddr          (paddr),
        .pwdata         (pwdata),
        .prdata         (prdata),
        // Timer Config
        .tmr_ctrl       (tmr_ctrl),
        .tmr_presc      (tmr_presc),
        .tmr_load       (tmr_load),
        .tmr_cmp        (tmr_cmp),
        .tmr_cnt        (tmr_cnt),
        // ADC Config & Status
        .adc_ctrl       (adc_ctrl),
        .adc_smp        (adc_smp),
        .adc_div        (adc_div),
        .adc_thr_lo     (adc_thr_lo),
        .adc_thr_hi     (adc_thr_hi),
        .adc_stat       ({1'b0, adc_busy, fifo_full, fifo_empty, fifo_level}),
        .adc_rch        ({!fifo_empty, 1'b0, fifo_rdata[9:8], 4'h0}), // Read channel without pop
        .adc_data_fifo  (fifo_rdata[7:0]),
        .fifo_pop       (fifo_pop),
        // IRQ Management
        .irq_en         (), // Quản lý nội bộ trong apb_regs8
        .irq_stat       (),
        .irq_events     ({trig_miss, fifo_ovr, adc_wd, adc_eoc, tmr_cmp_pulse, tmr_ovf_pulse}),
        .irq            (irq)
    );

    // ------------------------------------------------------------------------
    // 4. Khởi tạo Khối Timer 8-bit (timer8)
    // ------------------------------------------------------------------------
    timer8 u_timer (
        .clk            (clk),
        .rst_n          (rst_n),
        .en             (tmr_ctrl),
        .presc          (tmr_presc),
        .load           (tmr_load),
        .cmp            (tmr_cmp),
        .cnt            (tmr_cnt),
        .ovf_pulse      (tmr_ovf_pulse),
        .cmp_pulse      (tmr_cmp_pulse),
        .pwm_out        (pwm_out)
    );

    // ------------------------------------------------------------------------
    // 5. Khởi tạo Bộ điều khiển SAR ADC (sar_adc_ctrl)
    // ------------------------------------------------------------------------
    sar_adc_ctrl u_adc (
        .clk            (clk),
        .rst_n          (rst_n),
        .en             (adc_ctrl),
        .start          (adc_trig),
        .ch_in          (adc_ctrl[5:4]),
        .smp            (adc_smp),
        .div            (adc_div),
        .sample         (adc_sample),
        .ch             (adc_ch),
        .dac            (adc_dac),
        .cmp            (adc_cmp),
        .busy           (adc_busy),
        .eoc            (adc_eoc),
        .result         (adc_result)
    );

    // ------------------------------------------------------------------------
    // 6. Khởi tạo Khối FIFO Kết quả (sync_fifo - 8 slots x 10 bits)
    // ------------------------------------------------------------------------
    sync_fifo #(
        .W              (10)
    ) u_fifo (
        .clk            (clk),
        .rst_n          (rst_n),
        .push           (adc_eoc && !fifo_full),
        .din            ({adc_ch, adc_result}),
        .pop            (fifo_pop),
        .dout           (fifo_rdata),
        .level          (fifo_level),
        .empty          (fifo_empty),
        .full           (fifo_full),
        .overflow       (fifo_ovr)
    );

endmodule