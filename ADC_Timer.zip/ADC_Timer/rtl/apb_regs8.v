// apb_regs8.v - 16 thanh ghi 8 bit, co ngat, trigger ADC, giao tiep FIFO
//   Bang thanh ghi:
//   0 TMR_CTRL RW  [0]EN [1]ONESHOT        8 ADC_THR_LO RW
//   1 TMR_PRESC RW                          9 ADC_THR_HI RW
//   2 TMR_LOAD RW (reset FF)                A ADC_DATA  RO: doc = XEM dau FIFO; GHI bat ky = POP
//   3 TMR_CMP RW (reset 80)                 B ADC_RCH   RO: [7]VALID [1:0]CH
//   4 TMR_CNT RO                            C ADC_STAT  RO: [3:0]LEVEL [4]EMPTY [5]FULL [6]BUSY
//   5 ADC_CTRL RW [0]EN [1]START [3:2]TRIG_SEL [5:4]CH
//   6 ADC_SMP RW (reset 04)                 D IRQ_EN RW
//   7 ADC_DIV RW                            E IRQ_STAT W1C
//                                           F ID RO = A8
//   IRQ bit: 0 TMR_OVF 1 TMR_CMP 2 ADC_EOC 3 ADC_WD 4 FIFO_OVR 5 TRIG_MISS
//   TRIG_SEL: 0 phan mem (START) 1 timer overflow 2 timer compare 3 lien tuc
module apb_regs8 (
    input  wire       clk,
    input  wire       rst_n,
    // bus APB 8 bit
    input  wire       psel,
    input  wire       penable,
    input  wire       pwrite,
    input  wire [3:0] paddr,
    input  wire [7:0] pwdata,
    output reg  [7:0] prdata,
    output wire       irq,
    // timer
    output wire       tmr_en,
    output wire       tmr_oneshot,
    output wire [7:0] tmr_presc,
    output wire [7:0] tmr_load,
    output wire [7:0] tmr_cmp,
    input  wire [7:0] tmr_cnt,
    input  wire       tmr_ovf,
    input  wire       tmr_cmpp,
    // ADC
    output wire       adc_en,
    output wire       adc_start,
    output wire [1:0] adc_ch_sel,
    output wire [7:0] adc_smp,
    output wire [7:0] adc_div,
    input  wire       adc_busy,
    input  wire       adc_eoc,
    input  wire [7:0] adc_result,
    input  wire [1:0] adc_ch_done,
    // FIFO
    output wire       fifo_push,
    output wire       fifo_pop,
    output wire [9:0] fifo_din,
    input  wire [9:0] fifo_dout,
    input  wire [3:0] fifo_level,
    input  wire       fifo_empty,
    input  wire       fifo_full,
    input  wire       fifo_ovr
);
    reg       r_tmr_en, r_tmr_oneshot;
    reg [7:0] r_presc, r_load, r_cmp;
    reg       r_adc_en;
    reg [1:0] r_trig, r_ch;
    reg [7:0] r_smp, r_div, r_thr_lo, r_thr_hi;
    reg [5:0] r_irq_en, r_irq_stat;
    reg       sw_start_r;

    wire wr     = psel & penable & pwrite;
    wire wr_irq = wr && (paddr == 4'hE);

    // ---- trigger ADC ----
    wire trig_fire  = (r_trig == 2'd0 && sw_start_r) ||
                      (r_trig == 2'd1 && tmr_ovf)    ||
                      (r_trig == 2'd2 && tmr_cmpp);
    wire cont_start = r_adc_en && (r_trig == 2'd3) && !adc_busy;
    wire start_ok   = r_adc_en && trig_fire && !adc_busy;
    wire trig_miss  = r_adc_en && trig_fire &&  adc_busy;

    assign adc_start = start_ok | cont_start;

    // ---- window comparator ----
    wire wd = adc_eoc && ((adc_result < r_thr_lo) || (adc_result > r_thr_hi));

    // ---- su kien -> co ngat ----
    wire [5:0] set_mask = {trig_miss, fifo_ovr, wd, adc_eoc, tmr_cmpp, tmr_ovf};
    wire [5:0] clr_mask = wr_irq ? pwdata[5:0] : 6'd0;

    always @(posedge clk) begin
        if (!rst_n) begin
            r_tmr_en <= 1'b0; r_tmr_oneshot <= 1'b0;
            r_presc <= 8'h00; r_load <= 8'hFF; r_cmp <= 8'h80;
            r_adc_en <= 1'b0; r_trig <= 2'd0; r_ch <= 2'd0;
            r_smp <= 8'h04; r_div <= 8'h00;
            r_thr_lo <= 8'h00; r_thr_hi <= 8'hFF;
            r_irq_en <= 6'd0; r_irq_stat <= 6'd0;
            sw_start_r <= 1'b0;
        end else begin
            sw_start_r <= 1'b0;

            if (wr) begin
                case (paddr)
                    4'h0: begin r_tmr_en <= pwdata[0]; r_tmr_oneshot <= pwdata[1]; end
                    4'h1: r_presc  <= pwdata;
                    4'h2: r_load   <= pwdata;
                    4'h3: r_cmp    <= pwdata;
                    4'h5: begin
                        r_adc_en   <= pwdata[0];
                        sw_start_r <= pwdata[1];
                        r_trig     <= pwdata[3:2];
                        r_ch       <= pwdata[5:4];
                    end
                    4'h6: r_smp    <= pwdata;
                    4'h7: r_div    <= pwdata;
                    4'h8: r_thr_lo <= pwdata;
                    4'h9: r_thr_hi <= pwdata;
                    4'hD: r_irq_en <= pwdata[5:0];
                    default: ;   // RO / W1C / pop xu ly noi khac
                endcase
            end

            // one-shot: phan cung tu xoa EN (uu tien hon lenh ghi)
            if (tmr_ovf && r_tmr_oneshot) r_tmr_en <= 1'b0;

            // co ngat dinh: su kien phan cung thang lenh xoa cung clock
            r_irq_stat <= (r_irq_stat & ~clr_mask) | set_mask;
        end
    end

    assign tmr_en      = r_tmr_en;
    assign tmr_oneshot = r_tmr_oneshot;
    assign tmr_presc   = r_presc;
    assign tmr_load    = r_load;
    assign tmr_cmp     = r_cmp;
    assign adc_en      = r_adc_en;
    assign adc_ch_sel  = r_ch;
    assign adc_smp     = r_smp;
    assign adc_div     = r_div;

    assign fifo_push = adc_eoc;
    assign fifo_din  = {adc_ch_done, adc_result};
    assign fifo_pop  = wr && (paddr == 4'hA);      // ghi vao ADC_DATA = pop

    assign irq = |(r_irq_stat & r_irq_en);

    // ---- doc thanh ghi (to hop), 0 khi psel = 0 ----
    always @(*) begin
        prdata = 8'h00;
        if (psel) begin
            case (paddr)
                4'h0: prdata = {6'd0, r_tmr_oneshot, r_tmr_en};
                4'h1: prdata = r_presc;
                4'h2: prdata = r_load;
                4'h3: prdata = r_cmp;
                4'h4: prdata = tmr_cnt;
                4'h5: prdata = {2'd0, r_ch, r_trig, 1'b0, r_adc_en};   // START doc ra 0
                4'h6: prdata = r_smp;
                4'h7: prdata = r_div;
                4'h8: prdata = r_thr_lo;
                4'h9: prdata = r_thr_hi;
                4'hA: prdata = fifo_dout[7:0];                          // xem, khong pop
                4'hB: prdata = {~fifo_empty, 5'd0, fifo_dout[9:8]};
                4'hC: prdata = {1'b0, adc_busy, fifo_full, fifo_empty, fifo_level};
                4'hD: prdata = {2'd0, r_irq_en};
                4'hE: prdata = {2'd0, r_irq_stat};
                4'hF: prdata = 8'hA8;
            endcase
        end
    end
endmodule
