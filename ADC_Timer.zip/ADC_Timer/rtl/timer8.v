module timer8 (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       en,
    input  wire [7:0] presc,      // tick mỗi PRESC+1 clock
    input  wire [7:0] load,       // đếm 0..LOAD rồi wrap
    input  wire [7:0] cmp,        // ngưỡng compare / PWM
    output reg  [7:0] cnt,
    output reg        ovf_pulse,  // 1 clock khi wrap
    output reg        cmp_pulse,  // 1 clock khi cnt == CMP
    output wire       pwm_out
);
    reg [7:0] pre;

    always @(posedge clk) begin
        ovf_pulse <= 1'b0;
        cmp_pulse <= 1'b0;
        if (!rst_n || !en) begin          // EN=0: xóa counter + prescaler
            pre <= 8'd0;
            cnt <= 8'd0;
        end else if (pre < presc) begin
            pre <= pre + 8'd1;
        end else begin
            pre <= 8'd0;
            if (cnt == cmp) cmp_pulse <= 1'b1;
            if (cnt >= load) begin
                cnt       <= 8'd0;
                ovf_pulse <= 1'b1;
            end else begin
                cnt <= cnt + 8'd1;
            end
        end
    end

    assign pwm_out = en & (cnt < cmp);
endmodule