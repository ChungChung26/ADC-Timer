// timer_adc8_cpu_if.v - cau noi bus 1 clock cua CPU (cs/we) sang APB 8 bit
//   Moi LD/ST = 1 clock. Ghi (we=1) chi xay ra dung 1 lan cho moi lenh ST.
//   Doc khong co tac dung phu (ADC_DATA doc = xem, ghi = pop).
module timer_adc8_cpu_if (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       cs,
    input  wire       we,
    input  wire [3:0] addr,
    input  wire [7:0] wdata,
    output wire [7:0] rdata,      // = 0 khi cs = 0
    output wire       irq,
    output wire       pwm_out,
    output wire       adc_sample,
    output wire [1:0] adc_ch,
    output wire [7:0] adc_dac,
    input  wire       adc_cmp
);
    timer_adc8_top u_periph (
        .clk(clk), .rst_n(rst_n),
        .psel(cs), .penable(cs), .pwrite(we),
        .paddr(addr), .pwdata(wdata), .prdata(rdata),
        .irq(irq), .pwm_out(pwm_out),
        .adc_sample(adc_sample), .adc_ch(adc_ch),
        .adc_dac(adc_dac), .adc_cmp(adc_cmp)
    );
endmodule
