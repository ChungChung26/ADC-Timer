`timescale 1ns/1ps
// =====================================================================
//  tb_soc.v - CPU RISC-8 5 tang (cua thay, KHONG sua) + peripheral Timer/ADC
//  - risc8_5stage_core.v giu nguyen; chi thay rtl/dmem.v bang soc/dmem.v
//  - Chay program_soc.hex, cho HLT, kiem tra RAM + chan peripheral
//  - Mo hinh analog (sar_afe_model_mv) noi vao chan cua peripheral
//    ben trong dmem bang duong dan phan cap (giong cach tb cua thay doc u_dmem.mem)
// =====================================================================
module tb_soc;
    // Neu Vivado khong tim thay file, thay bang duong dan tuyet doi dung dau "/"
    localparam HEX_FILE = "program_soc.hex";

    reg clk = 0;
    reg rst = 1;
    wire       halted;
    wire [7:0] pc;
    wire [1:0] flags;
    wire       instr_done;

    risc8_5stage_core #(.IMEM_FILE(HEX_FILE)) dut (
        .clk(clk), .rst(rst), .halted(halted),
        .pc_out(pc), .flags_out(flags), .instr_done(instr_done)
    );

    initial forever #5 clk = ~clk;

    // ---- chan peripheral (doc tu ben trong dmem) ----
    wire       adc_sample = dut.u_dmem.adc_sample;
    wire [1:0] adc_ch     = dut.u_dmem.adc_ch;
    wire [7:0] adc_dac    = dut.u_dmem.adc_dac;
    wire       pwm_out    = dut.u_dmem.pwm_out;
    wire       irq        = dut.u_dmem.irq;

    // ---- dien ap dau vao 4 kenh (mV) ----
    reg [11:0] vin_mv0 = 12'd0, vin_mv1 = 12'd0, vin_mv2 = 12'd1111, vin_mv3 = 12'd2500;
    wire afe_cmp;

    sar_afe_model_mv afe (
        .sample(adc_sample), .ch(adc_ch), .dac(adc_dac),
        .vin_mv0(vin_mv0), .vin_mv1(vin_mv1), .vin_mv2(vin_mv2), .vin_mv3(vin_mv3),
        .cmp(afe_cmp)
    );
    always @(afe_cmp) dut.u_dmem.adc_cmp_sim = afe_cmp;      // comparator -> peripheral

    // ---- thong ke ----
    integer cycles = 0, retired = 0, errors = 0;
    integer pwm_edges = 0, irq_cycles = 0, ovf_cnt = 0, eoc_cnt = 0;
    reg pwm_d = 0;

    always @(posedge clk) if (!rst && !halted) begin
        cycles <= cycles + 1;
        if (instr_done) retired <= retired + 1;
    end
    always @(posedge clk) begin
        pwm_d <= pwm_out;
        if (pwm_out && !pwm_d) pwm_edges <= pwm_edges + 1;
        if (irq) irq_cycles <= irq_cycles + 1;
        if (dut.u_dmem.u_periph.u_periph.tmr_ovf) ovf_cnt <= ovf_cnt + 1;
        if (dut.u_dmem.u_periph.u_periph.adc_eoc) eoc_cnt <= eoc_cnt + 1;
    end

    task check_mem(input [7:0] a, input [7:0] exp, input [511:0] what);
        if (dut.u_dmem.mem[a] !== exp) begin
            $display("FAIL  MEM[%02h] = %02h, mong doi %02h  (%0s)", a, dut.u_dmem.mem[a], exp, what);
            errors = errors + 1;
        end else
            $display("PASS  MEM[%02h] = %02h  (%0s)", a, exp, what);
    endtask

    initial begin
        $dumpfile("tb_soc.vcd");
        $dumpvars(0, tb_soc);

        #22 rst = 0;
        wait (halted);
        repeat (3) @(posedge clk);

        $display("\n------------- kiem tra ket qua CPU + peripheral -------------");
        check_mem(8'h40, 8'h56, "A: ADC phan mem, 1111 mV -> 86");
        check_mem(8'h41, 8'h56, "B: mau 1 do timer kich");
        check_mem(8'h45, 8'h82, "ADC_RCH = VALID | CH2");
        check_mem(8'h42, 8'h07, "IRQ_STAT truoc khi xoa = OVF|CMP|EOC");
        check_mem(8'h43, 8'h00, "IRQ_STAT sau khi xoa (W1C)");
        check_mem(8'h44, 8'hA8, "ID");
        check_mem(8'hF5, 8'h00, "vung 0xF0-0xFF khong ghi vao RAM");

        if (pwm_edges < 1) begin $display("FAIL  chan pwm_out khong hoat dong"); errors = errors + 1; end
        else $display("PASS  pwm_out co %0d canh len", pwm_edges);
        if (irq_cycles < 1) begin $display("FAIL  chan irq khong len"); errors = errors + 1; end
        else $display("PASS  irq len %0d clock (CPU thang polling, irq chi de quan sat)", irq_cycles);
        if (irq !== 1'b0) begin $display("FAIL  irq con cao sau khi xoa co"); errors = errors + 1; end
        else $display("PASS  irq ha sau khi xoa co");
        if (eoc_cnt < 3) begin $display("FAIL  chi co %0d lan EOC", eoc_cnt); errors = errors + 1; end
        else $display("PASS  %0d lan chuyen doi hoan tat, %0d xung timer overflow", eoc_cnt, ovf_cnt);

        $display("\ncycles=%0d  instructions=%0d  CPI=%0.2f", cycles, retired, cycles * 1.0 / retired);
        if (errors == 0) $display("*** SOC: ALL TESTS PASSED ***");
        else             $display("*** SOC: %0d TEST(S) FAILED ***", errors);
        $finish;
    end

    initial begin #200000 $display("TIMEOUT: CPU khong dung (kiem tra program_soc.hex)"); $finish; end
endmodule
