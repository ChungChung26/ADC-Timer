// sar_afe_model_mv.sv - mo hinh analog (chi de mo phong), dien ap so nguyen mV
module sar_afe_model_mv (
    input  wire        sample,
    input  wire [1:0]  ch,
    input  wire [7:0]  dac,
    input  wire [11:0] vin_mv0, vin_mv1, vin_mv2, vin_mv3,
    output reg         cmp
);
    reg [11:0] vhold;

    initial begin vhold = 12'd0; cmp = 1'b0; end

    always @(negedge sample) begin
        case (ch)
            2'd0: vhold = vin_mv0;
            2'd1: vhold = vin_mv1;
            2'd2: vhold = vin_mv2;
            2'd3: vhold = vin_mv3;
        endcase
    end

    always @(vhold or dac) cmp = ((vhold * 256) >= (dac * 3300));
endmodule
