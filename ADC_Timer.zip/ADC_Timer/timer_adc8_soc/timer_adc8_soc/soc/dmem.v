// =====================================================================
//  soc/dmem.v  -  DMEM THAY THE cho ban SoC (CPU + Timer/ADC peripheral)
//  Cung ten module, cung cong (clk, we, addr, wdata, rdata) voi rtl/dmem.v
//  cua thay, nen risc8_5stage_core.v KHONG phai sua.
//    0x00-0xEF : RAM 240 byte (mang `mem` giu nguyen ten cho testbench)
//    0xF0-0xFF : thanh ghi peripheral Timer/ADC (addr[3:0] = so thanh ghi)
//  Luu y: core khong co tin hieu "dang doc", nen DOC KHONG CO TAC DUNG PHU.
//         Moi tac dung phu cua peripheral (pop FIFO, xoa co, start ADC)
//         deu chay bang LENH GHI (ST), vi `we` len dung 1 lan cho moi ST.
// =====================================================================
`timescale 1ns/1ps

module dmem (
    input  wire       clk,
    input  wire       we,
    input  wire [7:0] addr,
    input  wire [7:0] wdata,
    output wire [7:0] rdata
);
    // ---------------- RAM ----------------
    reg [7:0] mem [0:255];
    integer i;
    initial for (i = 0; i < 256; i = i + 1) mem[i] = 8'h00;

    wire io_sel = (addr[7:4] == 4'hF);

    always @(posedge clk)
        if (we && !io_sel) mem[addr] <= wdata;

    // ---------------- reset khi cap nguon cho peripheral ----------------
    // (dmem khong nhan rst tu core) 4 clock dau sau khi cap nguon.
    reg [1:0] por_cnt = 2'd0;
    wire      rst_n   = (por_cnt == 2'd3);
    always @(posedge clk) if (!rst_n) por_cnt <= por_cnt + 2'd1;

    // ---------------- peripheral ----------------
    wire [7:0] io_rdata;
    wire       irq;                 // chua noi vao dau (core khong co ngat)
    wire       pwm_out;
    wire       adc_sample;
    wire [1:0] adc_ch;
    wire [7:0] adc_dac;
    reg        adc_cmp_sim = 1'b0;  // testbench ghi vao day (mo hinh comparator)

    timer_adc8_cpu_if u_periph (
        .clk(clk), .rst_n(rst_n),
        .cs(io_sel), .we(we), .addr(addr[3:0]), .wdata(wdata), .rdata(io_rdata),
        .irq(irq), .pwm_out(pwm_out),
        .adc_sample(adc_sample), .adc_ch(adc_ch), .adc_dac(adc_dac),
        .adc_cmp(adc_cmp_sim)
    );

    assign rdata = io_sel ? io_rdata : mem[addr];
endmodule
