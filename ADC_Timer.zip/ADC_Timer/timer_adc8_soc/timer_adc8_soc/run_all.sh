#!/bin/sh
# Chay toan bo kiem tra bang Icarus Verilog (iverilog 12+).
# Dung: TEACHER=/duong/dan/risc8_5stage ./run_all.sh
T=${TEACHER:-../risc8_5stage}/rtl
set -e
echo "== timer8";      iverilog -g2012 -o /tmp/a.vvp rtl/timer8.v tb/tb_timer8.v && vvp /tmp/a.vvp | grep -E "PASS|FAIL"
echo "== sync_fifo";   iverilog -g2012 -o /tmp/b.vvp rtl/sync_fifo.v tb/tb_sync_fifo.sv && vvp /tmp/b.vvp | grep -E "PASS|FAIL"
echo "== regs + top (APB)"; iverilog -g2012 -o /tmp/c.vvp rtl/*.v sv/sar_afe_model_mv.sv tb/tb_top_apb.v && vvp /tmp/c.vvp | grep -E "PASS|FAIL"
echo "== SoC (CPU cua thay + peripheral)"
( cd soc && iverilog -g2012 -o /tmp/d.vvp $T/alu.v $T/control_unit.v $T/hazard_unit.v $T/imem.v \
    $T/regfile.v $T/risc8_5stage_core.v dmem.v ../rtl/*.v ../sv/sar_afe_model_mv.sv ../tb/tb_soc.v \
  && vvp /tmp/d.vvp | grep -E "FAIL|PASSED|TIMEOUT|cycles" )
