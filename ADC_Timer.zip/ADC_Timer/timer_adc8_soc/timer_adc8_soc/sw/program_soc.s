; program_soc.s - CPU RISC-8 dieu khien peripheral Timer + ADC (polling)
; Ban do: 0xF0 TMR_CTRL 0xF1 TMR_PRESC 0xF2 TMR_LOAD 0xF3 TMR_CMP 0xF5 ADC_CTRL
;         0xFA ADC_DATA (doc=xem, ghi=pop) 0xFB ADC_RCH 0xFC ADC_STAT
;         0xFD IRQ_EN 0xFE IRQ_STAT 0xFF ID
; Ket qua luu o RAM: 0x40..0x45

        ; ---- bat co ngat EOC (cong irq chi de quan sat, CPU khong co ngat) ----
        LDI  r1, 0xFD
        LDI  r2, 0x04
        ST   r2, [r1]          ; IRQ_EN = EOC

        ; ---- A: chuyen doi bang phan mem, kenh 2 ----
        LDI  r1, 0xF5
        LDI  r2, 0x23          ; EN | START | CH=2 | TRIG=phan mem
        ST   r2, [r1]
        LDI  r3, 0xFC          ; dia chi ADC_STAT
        LDI  r4, 0x10          ; mat na bit EMPTY
pollA:  LD   r5, [r3]
        AND  r5, r5, r4        ; khac 0 khi FIFO con rong
        BNZ  pollA
        LDI  r6, 0xFA          ; dia chi ADC_DATA
        LD   r7, [r6]          ; xem ket qua
        ST   r7, [r6]          ; ghi bat ky = pop
        LDI  r1, 0x40
        ST   r7, [r1]          ; mem[0x40] = ket qua A

        ; ---- B: timer overflow kich ADC, doc 2 mau ----
        LDI  r1, 0xF2
        LDI  r2, 19
        ST   r2, [r1]          ; TMR_LOAD = 19 (chu ky 20 clock)
        LDI  r1, 0xF3
        LDI  r2, 5
        ST   r2, [r1]          ; TMR_CMP = 5
        LDI  r1, 0xF5
        LDI  r2, 0x25          ; EN | TRIG=timer overflow | CH=2
        ST   r2, [r1]
        LDI  r1, 0xF0
        LDI  r2, 0x01
        ST   r2, [r1]          ; bat timer
pollB1: LD   r5, [r3]
        AND  r5, r5, r4
        BNZ  pollB1
        LD   r7, [r6]
        ST   r7, [r6]          ; pop mau 1
        LDI  r1, 0x41
        ST   r7, [r1]          ; mem[0x41] = mau 1
pollB2: LD   r5, [r3]
        AND  r5, r5, r4
        BNZ  pollB2
        LDI  r1, 0xFB
        LD   r2, [r1]          ; ADC_RCH = VALID | CH
        LDI  r1, 0x45
        ST   r2, [r1]          ; mem[0x45] = 0x82
        LD   r7, [r6]
        ST   r7, [r6]          ; pop mau 2

        ; ---- tat timer va ADC ----
        LDI  r2, 0x00
        LDI  r1, 0xF0
        ST   r2, [r1]
        LDI  r1, 0xF5
        ST   r2, [r1]

        ; ---- co ngat: doc roi xoa bang ghi 1 (W1C) ----
        LDI  r1, 0xFE
        LD   r2, [r1]
        LDI  r5, 0x42
        ST   r2, [r5]          ; mem[0x42] = IRQ_STAT truoc khi xoa (mong doi 0x07)
        LDI  r2, 0x07
        ST   r2, [r1]          ; xoa OVF | CMP | EOC
        LD   r2, [r1]
        LDI  r5, 0x43
        ST   r2, [r5]          ; mem[0x43] = IRQ_STAT sau khi xoa (mong doi 0x00)

        ; ---- doc ID ----
        LDI  r1, 0xFF
        LD   r2, [r1]
        LDI  r5, 0x44
        ST   r2, [r5]          ; mem[0x44] = 0xA8
        HLT
