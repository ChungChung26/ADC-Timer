#!/usr/bin/env python3
"""asm8.py - assembler toi thieu cho RISC-8 5 tang.
   Dinh dang lenh: [15:12] opcode | [11:9] rd | [8:6] rs1 | [5:3] rs2 | [7:0] imm8
   Dung: python3 asm8.py program.s program.hex"""
import re, sys

OPS = dict(NOP=0, ADD=1, SUB=2, AND=3, OR=4, XOR=5, SHL=6, SHR=7,
           LDI=8, ADDI=9, LD=10, ST=11, JMP=12, BZ=13, BNZ=14, HLT=15)

def reg(tok):
    m = re.fullmatch(r'[rR]([0-7])', tok.strip())
    if not m: raise ValueError(f'thanh ghi sai: {tok}')
    return int(m.group(1))

def num(tok, labels):
    tok = tok.strip()
    if tok in labels: return labels[tok]
    return int(tok, 0)

def split_ops(s):
    return [t for t in re.split(r'[,\s]+', s.replace('[', ' ').replace(']', ' ')) if t]

def assemble(lines):
    labels, prog, pc = {}, [], 0
    for raw in lines:                                   # luot 1: nhan
        line = re.split(r';|//', raw)[0].strip()
        while ':' in line:
            lab, line = line.split(':', 1)
            labels[lab.strip()] = pc
            line = line.strip()
        if line:
            prog.append((raw, line)); pc += 1
    words = []
    for raw, line in prog:                              # luot 2: ma hoa
        mn, *rest = line.split(None, 1)
        mn = mn.upper(); a = split_ops(rest[0]) if rest else []
        op = OPS[mn]; rd = rs1 = rs2 = imm = 0
        if mn in ('ADD', 'SUB', 'AND', 'OR', 'XOR'):
            rd, rs1, rs2 = reg(a[0]), reg(a[1]), reg(a[2])
        elif mn in ('SHL', 'SHR'):
            rd, rs1 = reg(a[0]), reg(a[1])
        elif mn in ('LDI', 'ADDI'):
            rd, imm = reg(a[0]), num(a[1], labels)
        elif mn in ('LD', 'ST'):
            rd, rs1 = reg(a[0]), reg(a[1])
        elif mn in ('JMP', 'BZ', 'BNZ'):
            imm = num(a[0], labels)
        w = (op << 12) | (rd << 9) | (rs1 << 6) | (rs2 << 3) | (imm & 0xFF)
        if mn in ('LDI', 'ADDI', 'JMP', 'BZ', 'BNZ'):
            w = (op << 12) | (rd << 9) | (imm & 0xFF)
        words.append((w, line))
    return words

if __name__ == '__main__':
    src, dst = sys.argv[1], sys.argv[2]
    words = assemble(open(src).read().splitlines())
    with open(dst, 'w') as f:
        for i, (w, line) in enumerate(words):
            f.write(f'{w:04X}   // {i:02X}: {line}\n')
    print(f'{len(words)} lenh -> {dst}')
