# Timer + ADC peripheral ghep voi CPU RISC-8 5 tang

Khong sua `risc8_5stage_core.v` va `tb_risc8_5stage.v` cua thay. Cach ghep: thay **rtl/dmem.v** cua thay
bang **soc/dmem.v** (cung ten module, cung cong) trong ban SoC. Vung 0xF0-0xFF cua bo nho du lieu
tro thanh 16 thanh ghi peripheral, 0x00-0xEF van la RAM.

## Cau truc
```
rtl/  timer8.v  sar_adc_ctrl.v  sync_fifo.v  apb_regs8.v  timer_adc8_top.v  timer_adc8_cpu_if.v
sv/   sar_afe_model_mv.sv                 (mo hinh analog, chi de mo phong)
soc/  dmem.v (thay the)  program_soc.hex  (chuong trinh mau da dich)
sw/   asm8.py  program_soc.s              (assembler toi thieu + ma nguon chuong trinh)
tb/   tb_top_apb.v  tb_soc.v  tb_timer8.v  tb_sync_fifo.sv
```

## Ban do thanh ghi (dia chi 0xF0 + offset)
| Off | Ten | Loai | Ghi chu |
|---|---|---|---|
| 0 | TMR_CTRL | RW | [0] EN, [1] ONESHOT (phan cung tu xoa EN) |
| 1 | TMR_PRESC | RW | tick moi PRESC+1 clock |
| 2 | TMR_LOAD | RW | reset FF |
| 3 | TMR_CMP | RW | reset 80 |
| 4 | TMR_CNT | RO | |
| 5 | ADC_CTRL | RW | [0] EN, [1] START (doc ra 0), [3:2] TRIG_SEL, [5:4] CH |
| 6 | ADC_SMP | RW | reset 04 |
| 7 | ADC_DIV | RW | |
| 8 | ADC_THR_LO | RW | |
| 9 | ADC_THR_HI | RW | reset FF |
| A | ADC_DATA | RO / pop | **DOC = XEM dau FIFO, GHI bat ky = POP** |
| B | ADC_RCH | RO | [7] VALID, [1:0] CH |
| C | ADC_STAT | RO | [3:0] LEVEL, [4] EMPTY, [5] FULL, [6] BUSY (reset 0x10) |
| D | IRQ_EN | RW | |
| E | IRQ_STAT | W1C | 0 OVF, 1 CMP, 2 EOC, 3 WD, 4 FIFO_OVR, 5 TRIG_MISS |
| F | ID | RO | A8 |

TRIG_SEL: 0 phan mem (bit START), 1 timer overflow, 2 timer compare, 3 lien tuc.
Thoi gian chuyen doi = (SMP+1+8) x (DIV+1) clock.

## Quyet dinh thiet ke do CPU cua thay
* Core khong co tin hieu "dang doc" -> moi tac dung phu chay bang lenh GHI (ST). Doc khong co tac dung phu.
* Core khong co ngat/RETI -> CPU thang polling. Chan `irq` cua peripheral van co (de quan sat, dung sau nay).
* dmem khong nhan `rst` tu core -> peripheral tu reset 4 clock sau khi cap nguon (`por_cnt`).
* Chan analog/PWM nam trong dmem nen khong ra duoc cong cua core: tb_soc noi mo hinh analog bang
  duong dan phan cap (`dut.u_dmem.*`). Chua tong hop duoc len board day du.

## Chay bang Icarus Verilog
`TEACHER=/duong/dan/risc8_5stage ./run_all.sh`

## Vivado 2026.1 - project SoC
Design sources: alu.v, control_unit.v, hazard_unit.v, imem.v, regfile.v, risc8_5stage_core.v (cua thay),
soc/dmem.v, rtl/*.v.  **Khong them rtl/dmem.v cua thay** (trung ten module).
Simulation sources: sv/sar_afe_model_mv.sv, tb/tb_soc.v, soc/program_soc.hex. Simulation top = `tb_soc`, run all.
Neu bao khong mo duoc program_soc.hex: dat duong dan tuyet doi (dau "/") vao `HEX_FILE` o dau tb_soc.v.
Kiem tra rieng peripheral (khong CPU): design = rtl/*.v, sim = sar_afe_model_mv.sv + tb_top_apb.v, top = `tb_top_apb`.

## Doi voi UVM da lam
timer8 co them cong `oneshot`. Trong tb_top_uvm.sv them `.oneshot(1'b0)` vao `timer8 dut_t (...)`,
va tuong tu trong tb_timer8.v (ban nay da co san).
