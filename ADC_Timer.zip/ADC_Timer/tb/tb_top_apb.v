`timescale 1ns/1ps
// tb_top_apb.v - kiem tra thanh ghi + 4 khoi qua cong APB (khong can CPU)
module tb_top_apb;
    reg clk = 0, rst_n = 0;
    reg psel = 0, penable = 0, pwrite = 0;
    reg [3:0] paddr = 0;
    reg [7:0] pwdata = 0;
    wire [7:0] prdata;
    wire irq, pwm_out, adc_sample, adc_cmp;
    wire [1:0] adc_ch;
    wire [7:0] adc_dac;
    reg [11:0] vin0 = 0, vin1 = 0, vin2 = 0, vin3 = 0;

    timer_adc8_top dut (
        .clk(clk), .rst_n(rst_n), .psel(psel), .penable(penable), .pwrite(pwrite),
        .paddr(paddr), .pwdata(pwdata), .prdata(prdata), .irq(irq), .pwm_out(pwm_out),
        .adc_sample(adc_sample), .adc_ch(adc_ch), .adc_dac(adc_dac), .adc_cmp(adc_cmp));

    sar_afe_model_mv afe (.sample(adc_sample), .ch(adc_ch), .dac(adc_dac),
        .vin_mv0(vin0), .vin_mv1(vin1), .vin_mv2(vin2), .vin_mv3(vin3), .cmp(adc_cmp));

    always #5 clk = ~clk;

    // cac dia chi thanh ghi
    localparam TMR_CTRL=0, TMR_PRESC=1, TMR_LOAD=2, TMR_CMP=3, TMR_CNT=4,
               ADC_CTRL=5, ADC_SMP=6, ADC_DIV=7, THR_LO=8, THR_HI=9,
               ADC_DATA=10, ADC_RCH=11, ADC_STAT=12, IRQ_EN=13, IRQ_STAT=14, ID=15;

    integer errors = 0;
    integer ovf_cnt = 0;
    reg [7:0] rd;

    always @(posedge clk) if (dut.tmr_ovf) ovf_cnt = ovf_cnt + 1;

    task apb_write(input [3:0] a, input [7:0] d);
    begin
        @(negedge clk); psel = 1; penable = 1; pwrite = 1; paddr = a; pwdata = d;
        @(negedge clk); psel = 0; penable = 0; pwrite = 0; paddr = 0; pwdata = 0;
    end
    endtask

    task apb_read(input [3:0] a, output [7:0] d);
    begin
        @(negedge clk); psel = 1; penable = 1; pwrite = 0; paddr = a;
        #1 d = prdata;
        @(negedge clk); psel = 0; penable = 0; paddr = 0;
    end
    endtask

    task expect_reg(input [3:0] a, input [7:0] e, input [511:0] name);
        reg [7:0] v;
    begin
        apb_read(a, v);
        if (v !== e) begin errors = errors + 1; $display("FAIL %0s: doc %02h, mong doi %02h (t=%0t)", name, v, e, $time); end
    end
    endtask

    task wait_not_empty(input integer max);
        integer n;
        reg [7:0] s;
    begin
        n = 0; s = 8'h10;
        while (s[4] && n < max) begin apb_read(ADC_STAT, s); n = n + 1; end
        if (s[4]) begin errors = errors + 1; $display("FAIL: timeout cho ket qua ADC"); end
    end
    endtask

    task wait_clks(input integer n);
    begin repeat (n) @(negedge clk); end
    endtask

    task drain_fifo;
        reg [7:0] s;
    begin
        apb_read(ADC_STAT, s);
        while (!s[4]) begin apb_write(ADC_DATA, 8'h00); apb_read(ADC_STAT, s); end
    end
    endtask

    integer i;
    integer ovf_before;

    initial begin
        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);

        // ---------- 1. gia tri reset ----------
        expect_reg(TMR_CTRL, 8'h00, "TMR_CTRL");   expect_reg(TMR_PRESC, 8'h00, "TMR_PRESC");
        expect_reg(TMR_LOAD, 8'hFF, "TMR_LOAD");   expect_reg(TMR_CMP,  8'h80, "TMR_CMP");
        expect_reg(TMR_CNT,  8'h00, "TMR_CNT");    expect_reg(ADC_CTRL, 8'h00, "ADC_CTRL");
        expect_reg(ADC_SMP,  8'h04, "ADC_SMP");    expect_reg(ADC_DIV,  8'h00, "ADC_DIV");
        expect_reg(THR_LO,   8'h00, "THR_LO");     expect_reg(THR_HI,   8'hFF, "THR_HI");
        expect_reg(ADC_DATA, 8'h00, "ADC_DATA");   expect_reg(ADC_RCH,  8'h00, "ADC_RCH");
        expect_reg(ADC_STAT, 8'h10, "ADC_STAT");   expect_reg(IRQ_EN,   8'h00, "IRQ_EN");
        expect_reg(IRQ_STAT, 8'h00, "IRQ_STAT");   expect_reg(ID,       8'hA8, "ID");

        // ---------- 2. ghi/doc, thanh ghi chi doc bo qua ghi ----------
        apb_write(TMR_PRESC, 8'h5A); expect_reg(TMR_PRESC, 8'h5A, "PRESC rw");
        apb_write(TMR_PRESC, 8'h00);
        apb_write(ID, 8'h00);        expect_reg(ID, 8'hA8, "ID ro");
        apb_write(TMR_CNT, 8'hFF);   expect_reg(TMR_CNT, 8'h00, "CNT ro");
        apb_write(ADC_STAT, 8'hFF);  expect_reg(ADC_STAT, 8'h10, "STAT ro");

        // ---------- 3. chuyen doi bang phan mem, kenh 2, 1111 mV ----------
        vin2 = 12'd1111;
        apb_write(ADC_SMP, 8'd2);
        apb_write(ADC_CTRL, 8'h23);                       // EN | START | CH=2 | TRIG=sw
        expect_reg(ADC_CTRL, 8'h21, "ADC_CTRL START doc ra 0");
        wait_not_empty(100);
        expect_reg(ADC_DATA, 8'h56, "ADC_DATA = 86");
        expect_reg(ADC_DATA, 8'h56, "ADC_DATA doc lan 2 khong pop");
        expect_reg(ADC_RCH,  8'h82, "ADC_RCH valid ch2");
        expect_reg(ADC_STAT, 8'h01, "STAT level=1");
        expect_reg(IRQ_STAT, 8'h04, "IRQ_STAT EOC");
        apb_write(ADC_DATA, 8'h00);                       // ghi = pop
        expect_reg(ADC_STAT, 8'h10, "STAT rong sau pop");
        expect_reg(ADC_RCH,  8'h00, "RCH rong");

        // ---------- 4. xoa co W1C, irq theo IRQ_EN ----------
        if (irq !== 1'b0) begin errors = errors + 1; $display("FAIL: irq phai thap (IRQ_EN=0)"); end
        apb_write(IRQ_EN, 8'h04);
        wait_clks(2);
        if (irq !== 1'b1) begin errors = errors + 1; $display("FAIL: irq phai cao"); end
        apb_write(IRQ_STAT, 8'h04);
        expect_reg(IRQ_STAT, 8'h00, "IRQ_STAT da xoa");
        if (irq !== 1'b0) begin errors = errors + 1; $display("FAIL: irq phai ha"); end
        apb_write(IRQ_EN, 8'h00);

        // ---------- 5. nhieu dien ap, kiem tra ma ----------
        vin2 = 12'd3300;
        apb_write(ADC_CTRL, 8'h23); wait_not_empty(100);
        expect_reg(ADC_DATA, 8'hFF, "3300 mV -> 255"); apb_write(ADC_DATA, 0);
        vin2 = 12'd0;
        apb_write(ADC_CTRL, 8'h23); wait_not_empty(100);
        expect_reg(ADC_DATA, 8'h00, "0 mV -> 0"); apb_write(ADC_DATA, 0);
        vin2 = 12'd2000;
        apb_write(ADC_CTRL, 8'h23); wait_not_empty(100);
        expect_reg(ADC_DATA, 8'h9B, "2000 mV -> 155"); apb_write(ADC_DATA, 0);
        vin3 = 12'd2500;
        apb_write(ADC_CTRL, 8'h33); wait_not_empty(100);          // CH=3
        expect_reg(ADC_DATA, 8'hC1, "ch3 2500 mV -> 193");
        expect_reg(ADC_RCH,  8'h83, "RCH ch3"); apb_write(ADC_DATA, 0);
        apb_write(IRQ_STAT, 8'h3F);

        // ---------- 6. cua so (window) ----------
        vin2 = 12'd1111;                                          // ket qua 86
        apb_write(THR_LO, 8'd100); apb_write(THR_HI, 8'd200);
        apb_write(ADC_CTRL, 8'h23); wait_not_empty(100); apb_write(ADC_DATA, 0);
        expect_reg(IRQ_STAT, 8'h0C, "WD khi 86 < LO=100 (EOC+WD)");
        apb_write(IRQ_STAT, 8'h3F);
        apb_write(THR_LO, 8'd86); apb_write(THR_HI, 8'd255);
        apb_write(ADC_CTRL, 8'h23); wait_not_empty(100); apb_write(ADC_DATA, 0);
        expect_reg(IRQ_STAT, 8'h04, "khong WD khi 86 = LO");
        apb_write(IRQ_STAT, 8'h3F);
        apb_write(THR_LO, 8'd0); apb_write(THR_HI, 8'd85);
        apb_write(ADC_CTRL, 8'h23); wait_not_empty(100); apb_write(ADC_DATA, 0);
        expect_reg(IRQ_STAT, 8'h0C, "WD khi 86 > HI=85");
        apb_write(IRQ_STAT, 8'h3F);
        apb_write(THR_HI, 8'hFF);

        // ---------- 7. che do lien tuc, FIFO day, co FIFO_OVR ----------
        apb_write(ADC_CTRL, 8'h2D);                               // EN | TRIG=3 | CH=2
        wait_clks(200);
        apb_write(ADC_CTRL, 8'h00);                               // tat ADC
        wait_clks(2);
        expect_reg(ADC_STAT, 8'h28, "FIFO day (level 8, FULL)");
        expect_reg(IRQ_STAT, 8'h14, "EOC + FIFO_OVR");
        for (i = 0; i < 8; i = i + 1) begin
            expect_reg(ADC_DATA, 8'h56, "du lieu trong FIFO");
            apb_write(ADC_DATA, 0);
        end
        expect_reg(ADC_STAT, 8'h10, "FIFO rong sau 8 pop");
        apb_write(IRQ_STAT, 8'h3F);

        // ---------- 8. huy giua chung bang EN = 0 ----------
        apb_write(ADC_CTRL, 8'h23);
        wait_clks(5);
        apb_write(ADC_CTRL, 8'h00);
        wait_clks(30);
        expect_reg(ADC_STAT, 8'h10, "khong co ket qua sau khi huy");
        expect_reg(IRQ_STAT, 8'h00, "khong co EOC sau khi huy");

        // ---------- 9. timer one-shot ----------
        apb_write(TMR_PRESC, 8'd1); apb_write(TMR_LOAD, 8'd4); apb_write(TMR_CMP, 8'd2);
        ovf_before = ovf_cnt;
        apb_write(TMR_CTRL, 8'h03);                               // EN | ONESHOT
        wait_clks(60);
        expect_reg(TMR_CTRL, 8'h02, "one-shot tu xoa EN");
        expect_reg(IRQ_STAT, 8'h03, "one-shot: OVF + CMP");
        if (ovf_cnt - ovf_before != 1) begin errors = errors + 1; $display("FAIL: one-shot overflow %0d lan", ovf_cnt - ovf_before); end
        apb_write(IRQ_STAT, 8'h3F);

        // ---------- 10. timer chay lien tuc, PWM ----------
        ovf_before = ovf_cnt;
        apb_write(TMR_CTRL, 8'h01);
        wait_clks(102);
        apb_write(TMR_CTRL, 8'h00);
        if (ovf_cnt - ovf_before < 9 || ovf_cnt - ovf_before > 11) begin
            errors = errors + 1; $display("FAIL: periodic overflow %0d lan (mong doi ~10)", ovf_cnt - ovf_before);
        end
        apb_write(IRQ_STAT, 8'h3F);

        // ---------- 11. timer kich ADC (overflow), khong miss ----------
        apb_write(TMR_PRESC, 8'd0); apb_write(TMR_LOAD, 8'd19); apb_write(TMR_CMP, 8'd5);
        apb_write(ADC_SMP, 8'd4);
        apb_write(ADC_CTRL, 8'h25);                               // EN | TRIG=1 | CH=2
        apb_write(TMR_CTRL, 8'h01);
        wait_clks(130);
        apb_write(TMR_CTRL, 8'h00); apb_write(ADC_CTRL, 8'h00);
        wait_clks(2);
        apb_read(ADC_STAT, rd);
        if (rd[3:0] < 4 || rd[3:0] > 6) begin errors = errors + 1; $display("FAIL: timer-trigger tao %0d ket qua (mong doi 5-6)", rd[3:0]); end
        apb_read(IRQ_STAT, rd);
        if (rd[5] !== 1'b0) begin errors = errors + 1; $display("FAIL: TRIG_MISS bat ngo"); end
        if (rd[2:0] !== 3'b111) begin errors = errors + 1; $display("FAIL: IRQ_STAT=%02h thieu OVF/CMP/EOC", rd); end
        drain_fifo;
        apb_write(IRQ_STAT, 8'h3F);

        // ---------- 12. timer nhanh hon ADC -> TRIG_MISS ----------
        apb_write(TMR_LOAD, 8'd5);                                // chu ky 6 < thoi gian chuyen doi 13
        apb_write(ADC_CTRL, 8'h25);
        apb_write(TMR_CTRL, 8'h01);
        wait_clks(60);
        apb_write(TMR_CTRL, 8'h00); apb_write(ADC_CTRL, 8'h00);
        apb_read(IRQ_STAT, rd);
        if (rd[5] !== 1'b1) begin errors = errors + 1; $display("FAIL: thieu co TRIG_MISS"); end

        // ---------- 13. ADC trigger bang timer compare ----------
        drain_fifo;
        apb_write(IRQ_STAT, 8'h3F);
        apb_write(TMR_LOAD, 8'd19); apb_write(TMR_CMP, 8'd7);
        apb_write(ADC_CTRL, 8'h29);                               // EN | TRIG=2 (compare) | CH=2
        apb_write(TMR_CTRL, 8'h01);
        wait_clks(60);
        apb_write(TMR_CTRL, 8'h00); apb_write(ADC_CTRL, 8'h00);
        apb_read(ADC_STAT, rd);
        if (rd[3:0] < 2) begin errors = errors + 1; $display("FAIL: trigger compare tao %0d ket qua", rd[3:0]); end

        if (errors == 0) $display("tb_top_apb: PASS"); else $display("tb_top_apb: FAIL (%0d loi)", errors);
        $finish;
    end

    initial begin #400000 $display("tb_top_apb: TIMEOUT"); $finish; end
endmodule
