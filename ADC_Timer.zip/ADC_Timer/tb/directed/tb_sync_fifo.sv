`timescale 1ns/1ps
module tb_sync_fifo;
    logic clk = 0, rst_n = 0, push = 0, pop = 0;
    logic [9:0] din = 0;
    wire  [9:0] dout;
    wire  [3:0] level;
    wire        empty, full, overflow;

    sync_fifo dut (.clk(clk), .rst_n(rst_n), .push(push), .din(din), .pop(pop),
                   .dout(dout), .level(level), .empty(empty), .full(full), .overflow(overflow));

    always #5 clk = ~clk;

    logic [9:0] q [$];          // mô hình tham chiếu
    bit         exp_ovf = 0;
    int         errors = 0;

    task check();
        logic [9:0] e = (q.size() > 0) ? q[0] : 10'd0;
        if (dout !== e)                 begin errors++; $display("FAIL dout=%0h exp=%0h (t=%0t)", dout, e, $time); end
        if (level !== q.size())         begin errors++; $display("FAIL level=%0d exp=%0d", level, q.size()); end
        if (empty !== (q.size() == 0))  begin errors++; $display("FAIL empty"); end
        if (full  !== (q.size() == 8))  begin errors++; $display("FAIL full"); end
        if (overflow !== exp_ovf)       begin errors++; $display("FAIL overflow=%0b exp=%0b", overflow, exp_ovf); end
    endtask

    // một chu kỳ: kiểm tra kết quả của chu kỳ trước, rồi lái chu kỳ mới và cập nhật mô hình
    task cycle(input bit p, input bit o, input logic [9:0] d);
        int pre;
        @(negedge clk);
        check();
        push = p; pop = o; din = d;
        pre = q.size();
        exp_ovf = p && (pre == 8);
        if (o && pre > 0) void'(q.pop_front());
        if (p && pre < 8) q.push_back(d);
    endtask

    initial begin
        repeat (3) @(negedge clk);
        rst_n = 1;

        for (int i = 0; i < 8; i++) cycle(1, 0, 10'h100 + i);   // đầy 8 mục
        cycle(1, 0, 10'h3FF);                                     // push khi đầy -> bỏ, overflow
        cycle(0, 0, 0);
        for (int i = 0; i < 8; i++) cycle(0, 1, 0);               // lấy hết, đúng thứ tự
        cycle(0, 1, 0);                                           // pop khi rỗng -> bỏ qua
        cycle(0, 0, 0);

        repeat (2000) cycle($urandom_range(0, 99) < 55, $urandom_range(0, 99) < 45, $urandom);
        cycle(0, 0, 0);
        cycle(0, 0, 0);

        if (errors == 0) $display("tb_sync_fifo: PASS"); else $display("tb_sync_fifo: FAIL (%0d loi)", errors);
        $finish;
    end
endmodule