package adc_pkg;
    import uvm_pkg::*;
    `include "uvm_macros.svh"

    class adc_smoke_test extends uvm_test;
        `uvm_component_utils(adc_smoke_test)

        virtual adc_if vif;

        function new(string name, uvm_component parent);
            super.new(name, parent);
        endfunction

        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            if (!uvm_config_db#(virtual adc_if)::get(this, "", "vif", vif)) begin
                `uvm_fatal("NOVIF", "virtual interface chua duoc set")
            end
        endfunction

        task run_phase(uvm_phase phase);
            int unsigned lat;
            phase.raise_objection(this);

            wait (vif.rst_n === 1'b1);
            repeat (2) @(negedge vif.clk);

            vif.vin_mv[2] = 12'd1111;
            vif.ch_in = 2'd2;
            vif.smp   = 8'd2;
            vif.div   = 8'd0;
            @(negedge vif.clk); vif.start = 1'b1;
            @(negedge vif.clk); vif.start = 1'b0;

            lat = 0;
            while (!vif.eoc && lat < 1000) begin
                @(negedge vif.clk);
                lat++;
            end

            `uvm_info("SMOKE", $sformatf("vin=1111 mV -> result=%0d (0x%02h), latency=%0d clocks",
                                         vif.result, vif.result, lat), UVM_LOW)
            if (vif.result !== 8'd86 || lat != 11) begin
                `uvm_error("SMOKE", "mong doi result=86 va 11 clock")
            end

            phase.drop_objection(this);
        endtask
    endclass
endpackage